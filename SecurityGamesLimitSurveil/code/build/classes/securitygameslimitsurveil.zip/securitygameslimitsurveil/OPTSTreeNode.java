package securitygameslimitsurveil;

import java.util.*;

public class OPTSTreeNode {
	public final static int OBSERVE = 1;
	public final static int ATTACK = 2;
	
	List<OPTSTreeNode> children;
	Map<Integer, Integer> observationMap;
	int attackedTarget;
	int maxDecision;
	int minDecision;
	int depth;
	double maxValue;
	double minValue;
	
	public OPTSTreeNode(int numPureStrategies, int depth){
		this.depth = depth;
		this.observationMap = new HashMap<Integer, Integer>();
		this.children = new ArrayList<OPTSTreeNode>();
		this.attackedTarget = -1;
			
		for(int i = 0; i < numPureStrategies; i++){
			children.add(new OPTSTreeNode(this, i, numPureStrategies, depth));
		}
	}
	
	public OPTSTreeNode(OPTSTreeNode parent, int observation, int numPureStrategies, int depth){
		observationMap = new HashMap<Integer, Integer>(parent.observationMap);
		
		if(observationMap.containsKey(observation)){
			observationMap.put(observation, observationMap.get(observation) + 1);
		}
		else{
			observationMap.put(observation, 1);
		}
		
		int numObservations = 0;
		
		for(Integer pureStrategy : observationMap.keySet()){
			numObservations += observationMap.get(pureStrategy);
		}
		
		if(numObservations < depth){
			children = new ArrayList<OPTSTreeNode>();
			
			for(int i = 0; i < numPureStrategies; i++){
				children.add(new OPTSTreeNode(this, i, numPureStrategies, depth));
			}
		}
	}
	
	public void setMaxDecision(int decision){
		this.maxDecision = decision;
	}
	
	public void setMinDecision(int decision){
		this.minDecision = decision;
	}
	
	public void setMaxValue(double value){
		this.maxValue = value;
	}
	
	public void setMinValue(double value){
		this.minValue = value;
	}
	
	public void setAttackedTarget(int target){
		this.attackedTarget = target;
	}
	
	public int getTreeDepth(){
		return depth;
	}
	
	public int getNumObservations(){
		int numObservations = 0;
		
		for(Integer pureStrategy : observationMap.keySet()){
			numObservations += observationMap.get(pureStrategy);
		}
		
		return numObservations;
	}
}
